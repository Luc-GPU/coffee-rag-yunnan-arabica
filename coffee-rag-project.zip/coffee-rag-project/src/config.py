"""
全局配置文件：用于控制消融实验开关
True 表示启用该优化，False 表示关闭
"""
# -*- coding: utf-8 -*-
import os

def _get_bool(name: str, default: bool) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return str(v).strip().lower() in ("1","true","yes","y","on")

# === 功能开关（消融） ===
ENABLE_SEMANTIC_CHUNK   = _get_bool("ENABLE_SEMANTIC_CHUNK",   True)
ENABLE_HYBRID_RETRIEVAL = _get_bool("ENABLE_HYBRID_RETRIEVAL", True)  # 若为 False，则按 RETRIEVAL_MODE 决定（dense/bm25）
ENABLE_RERANKER         = _get_bool("ENABLE_RERANKER",         True)
ENABLE_QUERY_REWRITE    = _get_bool("ENABLE_QUERY_REWRITE",    True)
ENABLE_HISTORY_INJECTION= _get_bool("ENABLE_HISTORY_INJECTION",True)
ENABLE_FINE_CITATION    = _get_bool("ENABLE_FINE_CITATION",    True)  # 是否强制/兜底插入 [docid#cid]

# === 检索模式/模型 ===
# hybrid / dense / bm25
RETRIEVAL_MODE          = os.getenv("RETRIEVAL_MODE", "hybrid").lower()

# 语义分块用的嵌入模型（仅分块决策）
EMBED_MODEL_SPLIT       = os.getenv("EMBED_MODEL_SPLIT", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")

# 向量库嵌入模型（相似度检索）
EMBED_MODEL_RETRIEVAL   = os.getenv("EMBED_MODEL_RETRIEVAL", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")

# Reranker 模型
RERANKER_MODEL          = os.getenv("RERANKER_MODEL", "BAAI/bge-reranker-base")

# === 检索/融合超参 ===
RERANK_CANDIDATES       = int(os.getenv("RERANK_CANDIDATES", "20"))
FINAL_TOPK              = int(os.getenv("FINAL_TOPK", "5"))
RRF_K                   = int(os.getenv("RRF_K", "60"))
BM25_TOKENIZER          = os.getenv("BM25_TOKENIZER", "jieba")  # jieba | whitespace

# === 语义分块参数 ===
SPLIT_MIN_CHARS         = int(os.getenv("SPLIT_MIN_CHARS", "200"))
SPLIT_MAX_CHARS         = int(os.getenv("SPLIT_MAX_CHARS", "600"))
SPLIT_HARD_SLICE        = int(os.getenv("SPLIT_HARD_SLICE", "350"))
SPLIT_SIM_THRESHOLD     = float(os.getenv("SPLIT_SIM_THRESHOLD", "0.36"))
