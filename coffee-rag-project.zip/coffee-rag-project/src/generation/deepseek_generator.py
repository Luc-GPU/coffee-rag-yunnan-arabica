# 使用 DeepSeek API 生成答案（面向“咖啡种植RAG评测”优化）
# -*- coding: utf-8 -*-
# src/generation/deepseek_generator.py
# 说明：
# - 保持 generate_answer_with_retriever / generate_answer_from_chunks 对外签名不变
# - 请求带重试/超时/代理/证书校验开关；可选离线兜底 OFFLINE_CITATION_FALLBACK
from __future__ import annotations

import os
import json
import requests
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from urllib3.exceptions import ProtocolError
import requests.exceptions as RE

from src.generation.response_builder import (
    build_prompt,
    extract_citations,
    _get_meta,
    _get_source,
    _get_chunk_id,
    _source_to_docid,
)
from src.memory.chat_memory import ChatMemory, DEFAULT_SESS_DIR
from src.retrieval.query_rewriter import build_query_from_history
from src.config import (
    ENABLE_HISTORY_INJECTION,
    ENABLE_QUERY_REWRITE,
    ENABLE_FINE_CITATION,
)

# ===== 环境 =====
load_dotenv()
API_KEY = os.getenv("DEEPSEEK_API_KEY")
API_URL = os.getenv("DEEPSEEK_API_URL", "https://api.deepseek.com/v1/chat/completions").rstrip("/")
MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")

TIMEOUT_S = float(os.getenv("DEEPSEEK_TIMEOUT", "60"))
MAX_RETRY = int(os.getenv("DEEPSEEK_RETRIES", "4"))
VERIFY_SSL = os.getenv("DEEPSEEK_VERIFY_SSL", "true").strip().lower() in ("1", "true", "yes", "on")
OFFLINE_FALLBACK = os.getenv("OFFLINE_CITATION_FALLBACK", "false").strip().lower() in ("1", "true", "yes", "on")

# 代理（如需）
_PROXIES: Dict[str, str] = {}
if os.getenv("HTTPS_PROXY"):
    _PROXIES["https"] = os.getenv("HTTPS_PROXY")
if os.getenv("HTTP_PROXY"):
    _PROXIES["http"] = os.getenv("HTTP_PROXY")

# 会话记忆
MAX_TURNS = int(os.getenv("CHAT_MAX_TURNS", "8"))
# 为避免上下文过长，对历史每条消息进行粗粒度截断
HIST_MAX_CHARS = int(os.getenv("CHAT_HISTORY_MAX_CHARS", "800"))

# ===== 带重试的 Session =====
_session = requests.Session()
_retry = Retry(
    total=MAX_RETRY,
    connect=MAX_RETRY,
    read=MAX_RETRY,
    backoff_factor=0.8,
    status_forcelist=(429, 500, 502, 503, 504),
    allowed_methods=frozenset(["POST"]),
    raise_on_status=False,
)
_adapter = HTTPAdapter(max_retries=_retry, pool_connections=10, pool_maxsize=10)
_session.mount("https://", _adapter)
_session.mount("http://", _adapter)


def _build_messages_with_history(
    sys_msg: Dict,
    usr_msg: Dict,
    hist: List[Dict],
    use_history: bool,
    max_turns: int = MAX_TURNS,
    max_chars: int = HIST_MAX_CHARS,
) -> List[Dict]:
    """
    将最近若干轮(user/assistant 交替)历史注入到 messages 中：
    - 仅在 use_history=True 时启用；
    - 取最近 max_turns 轮（约 2*max_turns 条消息）；
    - 为稳妥，按字符长度粗裁剪，避免上下文过长。
    """
    msgs: List[Dict[str, str]] = [sys_msg]
    if use_history and hist:
        recent = hist[-(max_turns * 2) :]
        for m in recent:
            role = "assistant" if m.get("role") == "assistant" else "user"
            content = m.get("content", "")
            if max_chars and len(content) > max_chars:
                # assistant 往往是长文本，保留前 max_chars；user 信息集中在尾部，保留后 max_chars
                content = (content[:max_chars] + " …") if role == "assistant" else ("…" + content[-max_chars:])
            msgs.append({"role": role, "content": content})
    msgs.append(usr_msg)
    return msgs


def _call_deepseek(messages: List[Dict], temperature: float = 0.2, max_tokens: int = 600) -> str:
    if not API_KEY:
        raise RuntimeError("❌ 未设置 DEEPSEEK_API_KEY")
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
    payload = {
        "model": MODEL,
        "messages": messages,
        "temperature": float(os.getenv("DEEPSEEK_TEMPERATURE", temperature)),
        "max_tokens": int(os.getenv("DEEPSEEK_MAX_TOKENS", max_tokens)),
        "stream": False,
    }
    try:
        resp = _session.post(
            API_URL,
            headers=headers,
            json=payload,
            timeout=TIMEOUT_S,
            verify=VERIFY_SSL,
            proxies=_PROXIES or None,
        )
        try:
            resp.raise_for_status()
        except RE.HTTPError as he:
            body = ""
            try:
                body = resp.text[:500]
            except Exception:
                pass
            raise RuntimeError(f"DeepSeek HTTP {resp.status_code}: {body}") from he

        data = resp.json()
        return (data.get("choices") or [{}])[0].get("message", {}).get("content", "") or ""
    except (RE.ChunkedEncodingError, ProtocolError) as e:
        raise RuntimeError(
            "DeepSeek 连接中断（ChunkedEncodingError/ProtocolError）。"
            "可提高 DEEPSEEK_TIMEOUT/DEEPSEEK_RETRIES，或开启 OFFLINE_CITATION_FALLBACK。"
        ) from e
    except RE.SSLError as e:
        hint = "（可临时 set DEEPSEEK_VERIFY_SSL=false；如用代理，配置 HTTPS_PROXY/HTTP_PROXY；或更新 certifi）"
        raise RuntimeError(f"DeepSeek SSL 握手失败：{e} {hint}") from e
    except RE.RequestException as e:
        raise RuntimeError(f"DeepSeek 请求失败：{e}") from e


def _append_jsonl(path: str, record: Dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def _ensure_citations(answer: str, top_chunks: List[Any], need_k: int = 3) -> List[str]:
    """
    从答案中抽取 [docid#cid]；若缺失且启用 ENABLE_FINE_CITATION，则从 top_chunks 兜底生成若干引用。
    """
    cites = extract_citations(answer)
    if cites or not ENABLE_FINE_CITATION:
        return cites
    # 兜底：从 top_chunks 构造 need_k 个引用标记
    out, used = [], set()
    for c in top_chunks[:need_k]:
        meta = _get_meta(c)
        did = _source_to_docid(_get_source(c), meta)
        cid = _get_chunk_id(c, 0)
        tag = f"[{did}#{cid}]"
        if tag not in used:
            used.add(tag)
            out.append(tag)
    return out


def _offline_fallback_citations(top_chunks: List[Any], need_k: int = 5) -> List[str]:
    out, used = [], set()
    for c in top_chunks[:need_k]:
        meta = _get_meta(c)
        did = _source_to_docid(_get_source(c), meta)
        cid = _get_chunk_id(c, 0)
        tag = f"[{did}#{cid}]"
        if did and tag not in used:
            used.add(tag)
            out.append(tag)
    return out


def generate_answer_from_chunks(
    session_id: str,
    query: str,
    top_chunks: List[Any],
    pred_out: str = "eval/pred.jsonl",
    use_rewrite: Optional[bool] = None,
    use_history: Optional[bool] = None,
) -> Dict[str, Any]:
    """
    直接给定检索到的 top_chunks 进行生成。
    - 历史注入：把最近 N 轮对话塞进 messages（受 ENABLE_HISTORY_INJECTION / use_history 控制）
    - 查询重写：仅影响用于构造 prompt 的 eff_query（受 ENABLE_QUERY_REWRITE / use_rewrite 控制）
    """
    mem = ChatMemory(DEFAULT_SESS_DIR)
    hist = mem.get_messages(session_id, max_turns=MAX_TURNS)

    eff_use_rewrite = ENABLE_QUERY_REWRITE if use_rewrite is None else bool(use_rewrite)
    eff_use_history = ENABLE_HISTORY_INJECTION if use_history is None else bool(use_history)

    eff_query = query
    if eff_use_rewrite:
        try:
            eff_query = build_query_from_history(hist, query, max_back=2)
        except Exception:
            eff_query = query

    # 统一使用（可能被重写的）eff_query 来构造 prompt
    prompt = build_prompt(eff_query, top_chunks)
    sys_msg = {
        "role": "system",
        "content": (
            "你是一名咖啡种植领域的检索增强问答助手。"
            "回答务必在需要的句子后使用 [docid#cid] 的引用标注，例如 [lit017#12]、[c16#27] 或 [86c5be63#5]。"
            "不要编造来源。"
        ),
    }
    usr_msg = {"role": "user", "content": prompt}

    offline_used = False
    error_text = ""
    try:
        messages = _build_messages_with_history(
            sys_msg=sys_msg,
            usr_msg=usr_msg,
            hist=hist,
            use_history=eff_use_history,
            max_turns=MAX_TURNS,
            max_chars=HIST_MAX_CHARS,
        )
        answer = _call_deepseek(messages, temperature=0.2, max_tokens=600)
    except Exception as e:
        error_text = str(e)
        if OFFLINE_FALLBACK:
            offline_used = True
            cites = _offline_fallback_citations(top_chunks, need_k=5)
            answer = "（离线兜底）参考文献：" + ("，".join(cites) if cites else "无")
        else:
            raise

    citations = _ensure_citations(answer, top_chunks, need_k=3)

    # 可选：当答案正文里完全没有 "#"（意味着没有任何 [docid#cid]）且已生成兜底引用，则在末尾追加一行保障论文口径
    if ENABLE_FINE_CITATION and citations and ("#" not in answer):
        answer = answer.rstrip() + "\n\n参考：" + " ".join(citations)

    # 持久化对话
    mem.append(session_id, "user", query)
    mem.append(session_id, "assistant", answer)

    rec: Dict[str, Any] = {
        "query": query,
        "answer": answer,
        "citations": citations,
        "hist_len_before": len(hist),
        "hist_used": min(len(hist), MAX_TURNS * 2) if eff_use_history else 0,
    }
    if offline_used or error_text:
        rec["error"] = error_text
        rec["offline_fallback"] = bool(offline_used)

    _append_jsonl(pred_out, rec)
    return {
        "answer": answer,
        "debug": {"citations": citations, "session_id": session_id, "offline": offline_used},
    }


def generate_answer_with_retriever(
    session_id: str,
    query: str,
    retriever,
    pred_out: str = "eval/pred.jsonl",
    use_rewrite: Optional[bool] = None,
    use_history: Optional[bool] = None,
) -> Dict[str, Any]:
    """
    通过 retriever（内部可含 Hybrid + RRF + 重排）先检索，再调用生成。
    - 查询重写：用于“检索阶段”的 retrieval_query
    - 生成阶段：会在 generate_answer_from_chunks 内部基于 eff_query 构造 prompt
    """
    mem = ChatMemory(DEFAULT_SESS_DIR)
    hist = mem.get_messages(session_id, max_turns=MAX_TURNS)

    eff_use_rewrite = ENABLE_QUERY_REWRITE if use_rewrite is None else bool(use_rewrite)
    retrieval_query = query
    if eff_use_rewrite:
        try:
            retrieval_query = build_query_from_history(hist, query, max_back=2)
        except Exception:
            retrieval_query = query

    top = retriever.get_relevant_documents(retrieval_query)
    return generate_answer_from_chunks(
        session_id=session_id,
        query=query,
        top_chunks=top,
        pred_out=pred_out,
        use_rewrite=use_rewrite,
        use_history=use_history,
    )


def generate_answer(query: str, top_chunks: List[Any], session_id: str = "default") -> Dict[str, Any]:
    """
    兼容旧接口：直接给 chunks 生成。
    """
    return generate_answer_from_chunks(session_id=session_id, query=query, top_chunks=top_chunks)
