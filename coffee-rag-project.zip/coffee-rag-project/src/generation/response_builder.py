# 拼接 prompt 资料块（健壮：兼容 dict / LangChain Document，字段缺失不报错）
# -*- coding: utf-8 -*-
# src/generation/response_builder.py
from __future__ import annotations
import os, re, hashlib
from typing import Any, Dict, List

# 允许 docid 为 lit017 / c16 / 86c5be63 / 自定义 token
_DOCID_OK = re.compile(r'^[A-Za-z0-9_-]{2,}$')

def _parse_stable_docid_from_source(source: str) -> str:
    s = os.path.basename(str(source or "")).lower()
    m = re.search(r'\blit[_\- ]*0*(\d{1,4})\b', s, flags=re.I)
    if m:
        return f"lit{int(m.group(1)):03d}"
    m = re.search(r'\bc[_\- ]*0*(\d{1,3})\b', s, flags=re.I)
    if m:
        return f"c{int(m.group(1))}"
    return hashlib.md5((os.path.basename(s) or s).encode("utf-8")).hexdigest()[:8]

def _get_meta(c: Any) -> Dict[str, Any]:
    if hasattr(c, "metadata"):
        return getattr(c, "metadata") or {}
    if isinstance(c, dict):
        return c.get("metadata") or {}
    return {}

def _get_source(c: Any) -> str:
    m = _get_meta(c)
    return c.get("source") if isinstance(c, dict) else (m.get("source") or "")

def _get_chunk_id(c: Any, default: int = 0) -> int:
    m = _get_meta(c)
    v = None
    if isinstance(c, dict):
        v = c.get("chunk_id")
    if v is None:
        v = m.get("chunk_id") or m.get("cid") or m.get("index") or default
    try:
        return int(v)
    except Exception:
        return default

def _source_to_docid(source: str, meta: Dict[str, Any] | None = None) -> str:
    """优先 meta.doc_id；否则从 source 解析；再回退 md5-hex8。"""
    meta = meta or {}
    d = meta.get("doc_id")
    if isinstance(d, str) and _DOCID_OK.match(d):
        return d.lower()
    return _parse_stable_docid_from_source(source)

def extract_citations(text: str) -> List[str]:
    """解析 [docid#cid]，docid 可为 lit017/c16/86c5be63 等。"""
    if not text:
        return []
    items = re.findall(r"\[\s*([A-Za-z0-9_-]{2,})\s*#\s*(\d+)\s*\]", text)
    norm = [f"[{d.lower()}#{int(c)}]" for d, c in items]
    seen, out = set(), []
    for s in norm:
        if s not in seen:
            seen.add(s); out.append(s)
    return out

def _format_source_line(c: Any) -> str:
    m = _get_meta(c)
    did = _source_to_docid(_get_source(c), m)
    cid = _get_chunk_id(c, 0)
    return f"[{did}#{cid}]"

def build_prompt(query: str, top_chunks: List[Any], k: int = 5) -> str:
    """
    将 top_k 块组织成带可引用的上下文。
    """
    pieces = []
    for ch in (top_chunks or [])[:k]:
        tag = _format_source_line(ch)
        txt = ""
        if hasattr(ch, "page_content"):
            txt = getattr(ch, "page_content") or ""
        elif isinstance(ch, dict):
            txt = (ch.get("text") or ch.get("page_content") or "")
        txt = str(txt).strip()
        if txt:
            pieces.append(f"{tag} {txt}")
    ctx = "\n\n".join(pieces)
    return (
        "你是咖啡种植领域的检索增强助手。请基于给定材料回答，不要编造或超出证据。"
        "对于关键事实，务必在相应句子后以 [docid#cid] 标注来源。\n\n"
        f"【材料】\n{ctx}\n\n"
        f"【问题】\n{query}\n\n"
        "【要求】\n"
        "1) 先给出直接答案；2) 如需数据与结论，句末追加 [docid#cid]；3) 只使用给定材料。"
    )

# 供其它模块调用的工具
__all__ = [
    "build_prompt", "extract_citations",
    "_get_meta", "_get_source", "_get_chunk_id", "_source_to_docid",
]
