# src/memory/chat_memory.py
import os, json
from typing import List, Dict
from datetime import datetime

# 固定 sessions 到项目根路径，避免 cwd 影响
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DEFAULT_SESS_DIR = os.path.join(PROJECT_ROOT, "sessions")

DEBUG_MEMORY = os.getenv("DEBUG_MEMORY", "0") == "1"

class ChatMemory:
    def __init__(self, base_dir: str = DEFAULT_SESS_DIR):
        self.base_dir = base_dir
        os.makedirs(self.base_dir, exist_ok=True)

    def _path(self, session_id: str) -> str:
        return os.path.join(self.base_dir, f"{session_id}.jsonl")

    def append(self, session_id: str, role: str, content: str) -> None:
        rec = {"role": role, "content": content, "ts": datetime.utcnow().isoformat()}
        path = self._path(session_id)
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        if DEBUG_MEMORY:
            print(f"[memory] append -> {os.path.abspath(path)} role={role} len={len(content)}")

    def load(self, session_id: str) -> List[Dict]:
        path = self._path(session_id)
        if not os.path.exists(path):
            return []
        out: List[Dict] = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except Exception:
                    continue
        return out

    def get_messages(self, session_id: str, max_turns: int = 8) -> List[Dict]:
        path = self._path(session_id)
        hist = self.load(session_id)
        ua = [m for m in hist if m.get("role") in ("user", "assistant")]
        max_msgs = max_turns * 2
        tail = ua[-max_msgs:]
        if DEBUG_MEMORY:
            print(f"[memory] load <- {os.path.abspath(path)} total={len(hist)} ua={len(ua)} return={len(tail)}")
        return [{"role": m["role"], "content": m["content"]} for m in tail]

    def clear(self, session_id: str) -> None:
        path = self._path(session_id)
        if os.path.exists(path):
            os.remove(path)
        if DEBUG_MEMORY:
            print(f"[memory] clear x {os.path.abspath(path)}")
