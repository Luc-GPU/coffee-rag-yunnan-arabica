# 融合语义检索与关键词检索（TF-IDF/BM25），返回相关 chunk
# src/retrieval/hybrid_retriever.py
# Hybrid = 向量相似度 + 中文 BM25（结巴分词） + RRF 融合，输出去重候选
# -*- coding: utf-8 -*-
from typing import List, Dict, Tuple, Any
import os, json
import numpy as np
from rank_bm25 import BM25Okapi
from src.retrieval.vector_store import load_vectorstore
from src.config import RRF_K, BM25_TOKENIZER

if BM25_TOKENIZER == "jieba":
    try:
        import jieba
        jieba.initialize()
        def zh_cut(s: str): return [w.strip() for w in jieba.cut(s or "", HMM=False) if w.strip()]
    except Exception:
        def zh_cut(s: str): return list((s or "").strip())
else:
    def zh_cut(s: str): return (s or "").split()

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
CHUNKS_PATH   = os.path.join(PROJECT_ROOT, "data", "processed_chunks", "chunks.jsonl")

_BM25 = None
_BM25_RAW: List[Dict] = []

def _ensure_bm25():
    global _BM25, _BM25_RAW
    if _BM25 is not None: return
    if not os.path.exists(CHUNKS_PATH):
        _BM25 = None; _BM25_RAW = []; return
    raw = []
    with open(CHUNKS_PATH, "r", encoding="utf-8") as f:
        for line in f:
            try:
                d = json.loads(line)
                if (d.get("text") or "").strip(): raw.append(d)
            except Exception: continue
    _BM25_RAW = raw
    corpus = [zh_cut(d.get("text") or "") for d in raw]
    _BM25 = BM25Okapi(corpus)

def _bm25_search(query: str, top_k: int) -> List[Tuple[Dict, float]]:
    _ensure_bm25()
    if not _BM25: return []
    scores = _BM25.get_scores(zh_cut(query))
    idx = np.argsort(scores)[::-1][:top_k]
    out = []
    for i in idx:
        d = _BM25_RAW[i]
        out.append(({
            "text": d.get("text") or "",
            "metadata": {"source": d.get("source"), "chunk_id": int(d.get("chunk_id") or 0), "doc_id": d.get("doc_id")}
        }, float(scores[i])))
    return out

def _dense_search(query: str, top_k: int) -> List[Tuple[Any, float]]:
    vs = load_vectorstore()
    res = vs.similarity_search_with_score(query, k=top_k)
    return [({"text": getattr(doc,"page_content",""),
              "metadata": getattr(doc,"metadata",{}) or {}}, -float(score)) for doc, score in res]

def _rrf_merge(dense: List[Tuple[Dict,float]], sparse: List[Tuple[Dict,float]], top_k: int) -> List[Dict]:
    pool, ranks = {}, {}
    def key(d: Dict):
        m = d.get("metadata") or {}
        return (str(m.get("source","")), int(m.get("chunk_id") or 0))
    for rank,(doc,_) in enumerate(dense,1):
        k=key(doc); pool[k]=doc; ranks[k]=ranks.get(k,0.0)+1.0/(RRF_K+rank)
    for rank,(doc,_) in enumerate(sparse,1):
        k=key(doc); pool.setdefault(k,doc); ranks[k]=ranks.get(k,0.0)+1.0/(RRF_K+rank)
    ordered = sorted(ranks.items(), key=lambda x:x[1], reverse=True)[:top_k]
    return [pool[k] for k,_ in ordered]

def dense_only(query: str, top_k: int = 20, dense_k: int = 60) -> List[Dict]:
    dense = _dense_search(query, top_k=dense_k)
    return [d for d,_ in dense[:top_k]]

def bm25_only(query: str, top_k: int = 20, bm25_k: int = 200) -> List[Dict]:
    sparse = _bm25_search(query, top_k=bm25_k)
    return [d for d,_ in sparse[:top_k]]

def hybrid(query: str, top_k: int = 20, dense_k: int = 60, bm25_k: int = 200) -> List[Dict]:
    dense = _dense_search(query, top_k=dense_k)
    sparse = _bm25_search(query, top_k=bm25_k)
    return _rrf_merge(dense, sparse, top_k=top_k)
