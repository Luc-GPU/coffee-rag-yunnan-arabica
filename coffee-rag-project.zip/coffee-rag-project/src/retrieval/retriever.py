#把你现有的 hybrid_retrieve + rerank 包装成一个标准 retriever（提供 get_relevant_documents()）
# src/retrieval/retriever.py
# 统一检索入口：Hybrid 召回 + 可选 Rerank
# -*- coding: utf-8 -*-
from typing import List, Any
from src.config import ENABLE_RERANKER, ENABLE_HYBRID_RETRIEVAL, RETRIEVAL_MODE, RERANK_CANDIDATES, FINAL_TOPK
from src.retrieval.hybrid_retriever import hybrid, dense_only, bm25_only
from src.retrieval.reranker import rerank

class PipelineRetriever:
    def __init__(self, cand_k: int = None, final_k: int = None):
        self.cand_k = cand_k or int(RERANK_CANDIDATES)
        self.final_k = final_k or int(FINAL_TOPK)

    def get_relevant_documents(self, query: str) -> List[Any]:
        mode = (RETRIEVAL_MODE or "hybrid").lower()
        if not ENABLE_HYBRID_RETRIEVAL:
            if mode not in ("dense","bm25","hybrid"): mode="dense"
        # 召回
        if mode == "dense":
            cands = dense_only(query, top_k=self.cand_k, dense_k=max(2*self.cand_k, 40))
        elif mode == "bm25":
            cands = bm25_only(query, top_k=self.cand_k, bm25_k=max(6*self.cand_k, 180))
        else:
            cands = hybrid(query, top_k=self.cand_k, dense_k=max(2*self.cand_k, 40), bm25_k=max(6*self.cand_k, 180))
        # 重排
        if ENABLE_RERANKER:
            return rerank(query, cands, top_k=self.final_k)
        return cands[:self.final_k]

my_retriever = PipelineRetriever()

