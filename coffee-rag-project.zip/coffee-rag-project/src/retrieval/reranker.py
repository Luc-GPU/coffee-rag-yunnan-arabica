# 使用 Cross-Encoder 对候选 chunk 重排序
# src/retrieval/reranker.py
# 中文效果更好的交叉编码器重排（BAAI/bge-reranker-base）
# -*- coding: utf-8 -*-
from typing import List, Dict
from sentence_transformers import CrossEncoder
import torch
from src.config import RERANKER_MODEL

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
_reranker = None

def _get_model() -> CrossEncoder:
    global _reranker
    if _reranker is None:
        _reranker = CrossEncoder(RERANKER_MODEL, device=DEVICE)
    return _reranker

def rerank(query: str, candidate_chunks: List[Dict], top_k: int = 5) -> List[Dict]:
    if not candidate_chunks: return []
    model = _get_model()
    pairs = [(query, (c.get("text") or "")) for c in candidate_chunks]
    scores = model.predict(pairs)
    ranked = sorted(zip(candidate_chunks, scores), key=lambda x: float(x[1]), reverse=True)
    return [c for c,_ in ranked[:top_k]]

