# -*- coding: utf-8 -*-
# src/retrieval/vector_store.py
# 作用：
# - 统一 doc_id（优先 lit### / c##，否则回退 8位hex）
# - 提供 build_vectorstore_from_chunks(...) 与 load_vectorstore(...)
# - 与 Chroma 0.4+ 兼容（自动持久化）

from __future__ import annotations
import os, re, hashlib
from typing import List, Dict, Any, Tuple

from langchain.schema import Document
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings

from src.config import EMBED_MODEL_RETRIEVAL

# ========= 稳定 doc_id 解析（优先 lit/c，其次回退 8hex） =========
def _parse_stable_docid_from_source(source: str) -> str:
    """
    从文件名解析稳定 docid：
    - lit：lit017 / lit-017 / lit_17 -> lit017（数字3位零填充）
    - c：  c16 / c-16 / c_16        -> c16   （不零填充）
    - 回退：basename 的 md5 前8位
    """
    s = os.path.basename(str(source or "")).lower()

    m = re.search(r'\blit[_\- ]*0*(\d{1,4})\b', s, flags=re.I)
    if m:
        return f"lit{int(m.group(1)):03d}"

    m = re.search(r'\bc[_\- ]*0*(\d{1,3})\b', s, flags=re.I)
    if m:
        return f"c{int(m.group(1))}"

    return hashlib.md5((os.path.basename(s) or s).encode("utf-8")).hexdigest()[:8]


def _to_document(ch: Dict[str, Any]) -> Document:
    """
    将 chunk(dict) 转为 LangChain Document，补齐 metadata：
      - page_content/text
      - metadata: source, chunk_id, doc_id(稳定)
    兼容你在 semantic_splitter 里已写入的字段。
    """
    text = (ch.get("text") or ch.get("page_content") or "").strip()
    meta = (ch.get("metadata") or {}).copy()
    source = ch.get("source") or meta.get("source") or ""
    # chunk id 兼容多个键名
    cid = ch.get("chunk_id", None)
    if cid is None:
        cid = meta.get("chunk_id") or meta.get("cid") or meta.get("index") or 0
    try:
        cid = int(cid)
    except Exception:
        cid = 0

    # 优先使用已有 doc_id；否则从 source 解析
    doc_id = (ch.get("doc_id") or meta.get("doc_id"))
    if not (isinstance(doc_id, str) and len(doc_id) >= 2):
        doc_id = _parse_stable_docid_from_source(source)

    meta.update({
        "source": source,
        "chunk_id": cid,
        "doc_id": doc_id,
    })
    return Document(page_content=text, metadata=meta)


# ========= Embeddings（单例缓存） =========
_embedding = None
def _get_embeddings():
    global _embedding
    if _embedding is None:
        _embedding = HuggingFaceEmbeddings(
            model_name=EMBED_MODEL_RETRIEVAL,
            encode_kwargs={"normalize_embeddings": True},
        )
    return _embedding


# ========= 构建与加载 =========
def build_vectorstore_from_chunks(chunks: List[Dict[str, Any]],
                                  persist_dir: str = "vector_db",
                                  collection_name: str = "coffee_rag") -> Tuple[Chroma, int]:
    """
    以稳定 doc_id 写入 Chroma 索引。
    返回 (vectorstore, 文档条数)
    """
    os.makedirs(persist_dir, exist_ok=True)
    docs: List[Document] = []
    for c in chunks:
        if (c.get("text") or c.get("page_content")):
            docs.append(_to_document(c))

    vs = Chroma.from_documents(
        documents=docs,
        embedding=_get_embeddings(),
        persist_directory=persist_dir,
        collection_name=collection_name,
    )
    try:
        vs.persist()  # 0.4+ 自动持久化，但显式调用更稳
    except Exception:
        pass
    return vs, len(docs)


def load_vectorstore(persist_dir: str = "vector_db",
                     collection_name: str = "coffee_rag") -> Chroma:
    """
    从已存在的 Chroma 持久化目录加载向量库。
    需与 build_knowledge_base.py 使用相同 persist_dir / collection_name。
    """
    if not os.path.isdir(persist_dir):
        raise FileNotFoundError(f"Chroma persist dir not found: {persist_dir}")
    # 直接指定 collection_name 与 embedding_function
    vs = Chroma(
        persist_directory=persist_dir,
        collection_name=collection_name,
        embedding_function=_get_embeddings(),
    )
    # 简单 sanity check：访问一次 count
    try:
        _ = vs._collection.count()  # 仅用于调试
    except Exception:
        pass
    return vs


__all__ = [
    "_parse_stable_docid_from_source",
    "build_vectorstore_from_chunks",
    "load_vectorstore",
]

