# src/retrieval/query_rewriter.py
from typing import List, Dict

def build_query_from_history(chat_messages: List[Dict], current_question: str, max_back: int = 2) -> str:
    """
    简单重写：把最近 max_back 条 user 问题提炼到一起，形成更清晰的检索查询。
    如果当前是指代（如“它”、“上面那个文件”），历史问题能补充语义。
    """
    prev_users = [m["content"] for m in chat_messages if m["role"] == "user"]
    tail = prev_users[-max_back:] if prev_users else []
    joined = " ".join(tail)
    # 你也可以在这里做指代消解/关键短语抽取（后续再增强）
    return f"{joined} {current_question}".strip()
