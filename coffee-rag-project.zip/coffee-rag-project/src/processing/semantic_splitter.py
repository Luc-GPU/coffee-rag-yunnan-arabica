# 按句分割文本并用嵌入模型进行语义感知分块（中文更稳）
# -*- coding: utf-8 -*-
# src/processing/semantic_splitter.py
import os, re, hashlib
from typing import List, Dict, Optional
import torch
from sentence_transformers import SentenceTransformer, util
from src.config import (EMBED_MODEL_SPLIT, SPLIT_MIN_CHARS, SPLIT_MAX_CHARS,
                        SPLIT_HARD_SLICE, SPLIT_SIM_THRESHOLD)

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
print(f"SemanticSplitter 使用设备: {DEVICE.upper()} | model={EMBED_MODEL_SPLIT}")

_SENT_ENDERS = set(list("。！？；;.!?"))
_RIGHT_QUOTES = "’”\"》）]）」』"

def _clean_text(t: str) -> str:
    if not t: return ""
    t = t.replace("\r\n","\n").replace("\r","\n")
    t = re.sub(r"[ \t]+"," ", t)
    t = re.sub(r"\n{3,}","\n\n", t)
    return t.strip()

def split_into_sentences(text: str) -> List[str]:
    text = (text or "").strip()
    if not text: return []
    sents, buff = [], []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]; buff.append(ch)
        if ch in _SENT_ENDERS:
            j = i + 1
            while j < n and text[j] in _RIGHT_QUOTES:
                buff.append(text[j]); j += 1
            sents.append("".join(buff).strip()); buff=[]
            i = j; continue
        if ch == "\n":
            seg = "".join(buff).strip()
            if seg: sents.append(seg); buff=[]
        i += 1
    if buff: sents.append("".join(buff).strip())

    out=[]
    for s in sents:
        if len(s) <= SPLIT_HARD_SLICE: out.append(s); continue
        start, L = 0, len(s)
        while start < L:
            end = min(L, start + SPLIT_HARD_SLICE); k=end
            while k > start and s[k-1] not in " ，,。；;：:、.!?！？\n":
                k-=1
            if k <= start + 50: k = end
            out.append(s[start:k].strip()); start = k
    return [x for x in out if x]

_model: Optional[SentenceTransformer] = None
def _get_model() -> SentenceTransformer:
    global _model
    if _model is None:
        _model = SentenceTransformer(EMBED_MODEL_SPLIT, device=DEVICE)
    return _model

def compute_sentence_embeddings(sentences: List[str]):
    if not sentences: return torch.empty(0, 384)
    emb = _get_model().encode(
        sentences, convert_to_tensor=True, normalize_embeddings=True,
        batch_size=64, show_progress_bar=False
    )
    if DEVICE == "cuda": emb = emb.cpu()
    return emb

def semantic_split(text: str, similarity_threshold: float = None) -> List[str]:
    sentences = split_into_sentences(text)
    if len(sentences)<=1: return sentences
    th = SPLIT_SIM_THRESHOLD if similarity_threshold is None else float(similarity_threshold)
    emb = compute_sentence_embeddings(sentences)
    chunks, cur = [], sentences[0]
    for i in range(1, len(sentences)):
        nxt = sentences[i]
        sim = float(util.cos_sim(emb[i-1], emb[i]).item())
        merged_len = len(cur)+1+len(nxt)
        should_merge = False
        if len(cur) < SPLIT_MIN_CHARS: should_merge = True
        elif sim >= th and merged_len <= SPLIT_MAX_CHARS: should_merge = True
        if should_merge:
            if merged_len <= SPLIT_MAX_CHARS:
                cur = cur + ("\n" if not cur.endswith("\n") else "") + nxt
            else:
                chunks.append(cur.strip()); cur = nxt
        else:
            chunks.append(cur.strip()); cur = nxt
    if cur.strip(): chunks.append(cur.strip())
    return [c for c in (x.strip() for x in chunks) if c]

# ===== 新增：从文件名解析稳定 doc_id（优先 lit### / c##，否则回退 8hex） =====
_DOCID_TOKEN = re.compile(r'^[A-Za-z0-9_-]{2,}$')

def _parse_stable_docid_from_source(source: str) -> str:
    s = os.path.basename(str(source or "")).lower()
    # lit-017 / lit_17 / lit17 → lit017
    m = re.search(r'\blit[_\- ]*0*(\d{1,4})\b', s, flags=re.I)
    if m: return f"lit{int(m.group(1)):03d}"
    # c-16 / c_16 / c16 → c16
    m = re.search(r'\bc[_\- ]*0*(\d{1,3})\b', s, flags=re.I)
    if m: return f"c{int(m.group(1))}"
    # 回退：basename 的 md5 前 8 位
    return hashlib.md5((os.path.basename(s) or s).encode("utf-8")).hexdigest()[:8]

def split_documents(documents: List[Dict], threshold: float = None) -> List[Dict]:
    """
    输出的每个 chunk 同时在 顶层 和 metadata 中写入稳定 doc_id，兼容下游：
      {
        "chunk_id": int, "source": str, "position": int,
        "text": str, "tokens": int, "doc_id": str,
        "metadata": {"source":..., "chunk_id":..., "position":..., "doc_id": ...}
      }
    """
    all_chunks, cid = [], 0
    for doc in documents:
        text = (doc.get("text") or "").strip()
        if not text: continue
        source = doc.get("source","")
        parts = semantic_split(text, similarity_threshold=threshold)

        # 为该文档解析一次稳定 doc_id（若上游已给 doc_id 则优先使用）
        doc_id = doc.get("doc_id")
        if not (isinstance(doc_id, str) and _DOCID_TOKEN.match(doc_id)):
            doc_id = _parse_stable_docid_from_source(source)

        for idx, part in enumerate(parts):
            rec = {
                "chunk_id": cid,
                "source": source,
                "position": idx,
                "text": part,
                "tokens": len(part.split()),
                "doc_id": doc_id,  # 顶层直写，便于直接消费
                "metadata": {
                    "source": source,
                    "chunk_id": cid,
                    "position": idx,
                    "doc_id": doc_id,  # metadata 里也写一份，兼容 LangChain Document.metadata
                }
            }
            all_chunks.append(rec)
            cid += 1
    return all_chunks
