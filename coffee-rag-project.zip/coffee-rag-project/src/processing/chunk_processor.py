# 为每个 chunk 添加 metadata 并保存到 processed_chunks/
# src/processing/chunk_processor.py

import os
import json
from typing import List, Dict

OUTPUT_DIR = "data/processed_chunks"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "chunks.jsonl")

def save_chunks_to_disk(chunks: List[Dict], output_path: str = OUTPUT_FILE) -> None:
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        for chunk in chunks:
            json.dump(chunk, f, ensure_ascii=False)
            f.write("\n")
    print(f"成功保存 {len(chunks)} 个 chunk 到 {output_path}")

def load_chunks_from_disk(path: str = OUTPUT_FILE) -> List[Dict]:
    if not os.path.exists(path):
        raise FileNotFoundError(f"未找到 chunk 文件: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return [json.loads(line.strip()) for line in f.readlines()]

if __name__ == "__main__":
    # 从 semantic_splitter 获取分块数据
    from document_loader import load_all_documents
    from semantic_splitter import split_documents

    raw_docs = load_all_documents("data/raw_documents")
    chunks = split_documents(raw_docs, threshold=0.75)
    save_chunks_to_disk(chunks)

    # 读取检查
    loaded = load_chunks_from_disk()
    print(f"从磁盘加载 chunk 数量: {len(loaded)}")
    print(loaded[:2])
