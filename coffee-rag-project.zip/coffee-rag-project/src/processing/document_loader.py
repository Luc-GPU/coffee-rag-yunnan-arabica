# 加载多种格式文档（.pdf/.docx/.txt/.md）并提取文本与元信息
# src/processing/document_loader.py

import os
import fitz  # PyMuPDF
import docx
import markdown
from typing import List, Dict

def load_pdf(file_path: str) -> List[Dict]:
    doc = fitz.open(file_path)
    results = []
    for page_num, page in enumerate(doc):
        text = page.get_text().strip()
        if text:
            results.append({
                "source": os.path.basename(file_path),
                "page": page_num + 1,
                "text": text
            })
    return results

def load_docx(file_path: str) -> List[Dict]:
    doc = docx.Document(file_path)
    results = []
    for i, para in enumerate(doc.paragraphs):
        text = para.text.strip()
        if text:
            results.append({
                "source": os.path.basename(file_path),
                "paragraph": i + 1,
                "text": text
            })
    return results

def load_txt_or_md(file_path: str) -> List[Dict]:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read().strip()
    if file_path.endswith(".md"):
        content = markdown.markdown(content)  # 可选转换为 HTML
    return [{
        "source": os.path.basename(file_path),
        "text": content
    }]

def load_document(file_path: str) -> List[Dict]:
    if file_path.endswith(".pdf"):
        return load_pdf(file_path)
    elif file_path.endswith(".docx"):
        return load_docx(file_path)
    elif file_path.endswith(".txt") or file_path.endswith(".md"):
        return load_txt_or_md(file_path)
    else:
        raise ValueError(f"不支持的文件格式: {file_path}")

def load_all_documents(folder_path: str) -> List[Dict]:
    all_chunks = []
    for file in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file)
        if os.path.isfile(file_path):
            try:
                chunks = load_document(file_path)
                all_chunks.extend(chunks)
            except Exception as e:
                print(f"加载失败: {file_path}，错误：{e}")
    return all_chunks

if __name__ == "__main__":
    # 示例：从 data/raw_documents/ 读取所有文档
    folder = "data/raw_documents"
    docs = load_all_documents(folder)
    print(f"成功加载文档数: {len(docs)}")
    for d in docs[:2]:  # 预览前两条
        print(d)
