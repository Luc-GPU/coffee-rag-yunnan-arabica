# 项目说明、使用方法
文献放入 raw_documents
建立向量数据库 build_knowledge_base
构建回答(未对齐) eval_precision_recall
对齐 build_id_map
F1 citation_scorer