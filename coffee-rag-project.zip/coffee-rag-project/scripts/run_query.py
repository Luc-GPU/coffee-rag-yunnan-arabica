# 一键流程：输入 query →（历史感知重写）→ 检索 → 生成回答
# scripts/run_query.py

from src.generation.deepseek_generator import generate_answer_with_retriever
from src.retrieval.retriever import my_retriever  # 需要 src/retrieval/retriever.py 导出 my_retriever
from src.memory.chat_memory import ChatMemory

SESSION_ID = "cli"  # 固定会话 ID；需要多会话可改成 uuid4()
memory = ChatMemory()  # 用于 /reset 清空会话历史

def _ask(prompt: str) -> str:
    """避免空输入写入历史；支持指令"""
    while True:
        s = input(prompt).strip()
        if s:
            return s
        print("输入为空，请重新输入。")

def main():
    print("提示：输入 /reset 可清空当前会话历史；输入 X 退出。")
    while True:
        query = _ask("\n请输入你的问题（输入 X 退出）:\n> ")

        # 退出
        if query.lower() == "x":
            return

        # 指令：重置会话历史
        if query.strip().lower() == "/reset":
            memory.clear(SESSION_ID)
            print(f"✅ 会话 {SESSION_ID} 已重置（已删除 sessions/{SESSION_ID}.jsonl）")
            continue

        print("\n调用大模型（含历史感知检索重写）中...")
        res = generate_answer_with_retriever(
            session_id=SESSION_ID,
            query=query,
            retriever=my_retriever,   # 内部：历史重写 → 检索（由 my_retriever 实现）→ 生成
            use_rewrite=True
        )

        answer = res["answer"]
        dbg = res.get("debug", {})

        # 显示答案
        print("\n生成答案：")
        print(answer)

        # 调试信息（确认历史已注入 & 路径正确）
        if dbg:
            print(f"\n[debug] session_id={dbg.get('session_id')}")
            print(f"[debug] session_file={dbg.get('session_file')}")
            print(f"[debug] hist_len_before={dbg.get('hist_len_before')}")
            print(f"[debug] hist_used={dbg.get('hist_used')}")
            hp = dbg.get("history_preview")
            if hp:
                print(f"[debug] history_preview={hp}")

if __name__ == "__main__":
    main()
