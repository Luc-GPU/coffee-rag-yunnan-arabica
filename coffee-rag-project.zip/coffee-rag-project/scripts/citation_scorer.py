# scripts/citation_scorer.py
# 计算引用级 Precision / Recall / F1（宏平均），支持 --id_map
import json, re, argparse, os
from collections import Counter

# 放宽：支持 lit/c/hex 任意 docid
PAIR_RE = re.compile(r"\[?\s*([A-Za-z0-9_-]{2,})\s*#\s*(\d+)\s*\]?", re.I)

def _load_jsonl(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")
    out=[]
    with open(path,"r",encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line: continue
            try:
                out.append(json.loads(line))
            except Exception:
                pass
    return out

def _pairs_from_string(s):
    return set((d.lower(), int(c)) for d,c in PAIR_RE.findall(s or ""))

def _pairs_from_list(lst):
    S=set()
    if not isinstance(lst, list): return S
    for v in lst:
        if isinstance(v, str):
            for d,c in PAIR_RE.findall(v):
                S.add((d.lower(), int(c)))
        elif isinstance(v, dict):
            docid = (v.get("docid") or v.get("doc_id") or v.get("id") or v.get("document_id") or "")
            chunk = (v.get("chunk") or v.get("cid") or v.get("page") or v.get("index") or v.get("position"))
            if isinstance(docid, str) and docid:
                try:
                    S.add((docid.lower(), int(chunk))); continue
                except Exception:
                    pass
            for key in ("ref", "citation", "text", "source"):
                if isinstance(v.get(key), str):
                    for d,c in PAIR_RE.findall(v[key]):
                        S.add((d.lower(), int(c)))
    return S

def _extract_pairs(rec):
    for key in ("citations", "pred_citations", "refs", "references", "evidence", "gold_citations"):
        if key in rec:
            S = _pairs_from_list(rec.get(key))
            if S: return S
    for key, val in rec.items():
        if isinstance(val, dict) and "citations" in val:
            S = _pairs_from_list(val["citations"])
            if S: return S
    return _pairs_from_string(rec.get("answer",""))

def _apply_id_map(pairs, id_map):
    if not id_map: return pairs
    return set((id_map.get(d, d).lower(), c) for d,c in pairs)

def _to_docs(pairs):
    return set(d for d,_ in pairs)

def _summarize(name, records, id_map=None, limit=10):
    docs = Counter()
    anypairs = 0
    for r in records:
        P = _extract_pairs(r)
        if id_map: P = _apply_id_map(P, id_map)
        anypairs += int(bool(P))
        for d,_ in P:
            docs[d]+=1
    print(f"[{name}] 有效样本: {anypairs}/{len(records)} 条含引用")
    most = docs.most_common(limit)
    if most:
        print(f"[{name}] Top docids: " + ", ".join(f"{d}({n})" for d,n in most))
    else:
        print(f"[{name}] 未解析到任何 docid/引用，请检查字段名或格式。")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--golden", default="eval/golden.jsonl")
    ap.add_argument("--pred",   default="eval/pred.jsonl")
    ap.add_argument("--id_map", default="eval/id_map.json")
    ap.add_argument("--level",  choices=["doc","chunk"], default="doc")
    ap.add_argument("--inspect", type=int, default=0)
    args=ap.parse_args()

    gold=_load_jsonl(args.golden)
    pred=_load_jsonl(args.pred)
    N=min(len(gold), len(pred))
    if N==0:
        print("No records to evaluate."); return

    id_map=None
    if args.id_map and os.path.exists(args.id_map):
        with open(args.id_map,"r",encoding="utf-8") as f:
            try:
                id_map={k.lower():v.lower() for k,v in json.load(f).items()}
                print(f"Loaded id_map from {args.id_map}, size={len(id_map)}")
            except Exception as e:
                print(f"读取 id_map 失败：{e}")

    _summarize("GOLD", gold, id_map=id_map)
    _summarize("PRED", pred, id_map=id_map)

    P_sum = R_sum = F1_sum = 0.0
    eps = 1e-8
    bad=[]

    for i in range(N):
        G=_apply_id_map(_extract_pairs(gold[i]), id_map)
        Pairs=_apply_id_map(_extract_pairs(pred[i]), id_map)

        if args.level=="doc":
            Gd=_to_docs(G); Pd=_to_docs(Pairs)
            tp=len(Gd & Pd)
            prec=tp/max(1,len(Pd)); rec=tp/max(1,len(Gd))
        else:
            tp=len(G & Pairs)
            prec=tp/max(1,len(Pairs)); rec=tp/max(1,len(G))

        f1_i = 2*prec*rec/(prec+rec+eps)
        P_sum+=prec; R_sum+=rec; F1_sum+=f1_i
        if args.inspect>0 and (prec==0 or rec==0):
            bad.append((i, list(G), list(Pairs)))

    macro_P = P_sum/max(1,N)
    macro_R = R_sum/max(1,N)
    macro_F1 = F1_sum/max(1,N)
    f1_from_macroPR = 2*macro_P*macro_R/(macro_P+macro_R+eps)

    print("=== 指标（宏平均）===")
    print(f"Precision: {macro_P:.3f}")
    print(f"Recall   : {macro_R:.3f}")
    print(f"F1       : {macro_F1:.3f}  (avg per-sample)")
    print(f"F1(P/R)  : {f1_from_macroPR:.3f}  (derived from macro P/R)")
    print(f"Count    : {N}")

    if args.inspect>0:
        print("\n--- 低分样例 ---")
        for i,(idx,G,P_) in enumerate(bad[:args.inspect],1):
            print(f"#{i} idx={idx}\n  G={G}\n  P={P_}\n")

if __name__=="__main__":
    main()
