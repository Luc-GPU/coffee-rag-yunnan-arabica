# 一键流程：加载 → 分块 → 嵌入 → 存入向量数据库（路径固定 & 打印写入位置）
# -*- coding: utf-8 -*-
# scripts/build_knowledge_base.py
import os
from src.processing.document_loader import load_all_documents
from src.processing.semantic_splitter import split_documents
from src.processing.chunk_processor import save_chunks_to_disk
from src.retrieval.vector_store import build_vectorstore_from_chunks

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RAW_DIR = os.path.join(PROJECT_ROOT, "data", "raw_documents")

if __name__ == "__main__":
    print("步骤1：加载文档...")
    documents = load_all_documents(RAW_DIR)
    print(f"加载文档数：{len(documents)}")

    print("\n步骤2：进行语义分块...")
    chunks = split_documents(documents, threshold=None)
    print(f"分块数：{len(chunks)}")

    print("\n步骤3：保存分块数据...")
    save_chunks_to_disk(chunks)

    print("\n步骤4：构建向量数据库...")
    build_vectorstore_from_chunks(chunks)

    print("\n知识库构建完成！")
