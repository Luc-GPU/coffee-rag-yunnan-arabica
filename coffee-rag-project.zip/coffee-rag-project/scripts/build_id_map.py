# -*- coding: utf-8 -*-
# scripts/build_id_map.py
# 从 golden.jsonl / pred.jsonl 的共现关系自动构建 docid 映射表
from __future__ import annotations
import os, re, json, argparse
from collections import Counter, defaultdict

PAIR_RE = re.compile(r"\[?\s*([A-Za-z0-9_-]{2,})\s*#\s*(\d+)\s*\]?", re.I)

def _load_jsonl(path):
    with open(path,"r",encoding="utf-8") as f:
        return [json.loads(x) for x in f if x.strip()]

def _extract_pairs(obj):
    def from_list(lst):
        S=set()
        for v in (lst or []):
            if isinstance(v,str):
                for d,c in PAIR_RE.findall(v): S.add((d.lower(), int(c)))
            elif isinstance(v,dict):
                d=(v.get("docid") or v.get("doc_id") or v.get("id") or v.get("document_id") or "")
                c=(v.get("chunk") or v.get("cid") or v.get("page") or v.get("index") or v.get("position"))
                if d:
                    try: S.add((d.lower(), int(c))); continue
                    except: pass
                for key in ("ref","citation","text","source"):
                    if isinstance(v.get(key), str):
                        for dd,cc in PAIR_RE.findall(v[key]): S.add((dd.lower(), int(cc)))
        return S

    for key in ("citations","pred_citations","refs","references","evidence","gold_citations"):
        if key in obj:
            S=from_list(obj.get(key));
            if S: return S
    # fallback
    return set((d.lower(), int(c)) for d,c in PAIR_RE.findall(obj.get("answer","")))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--golden", default="eval/golden.jsonl")
    ap.add_argument("--pred",   default="eval/pred.jsonl")
    ap.add_argument("--out",    default="eval/id_map.json")
    ap.add_argument("--min_votes", type=int, default=2, help="最少共现票数才收录映射")
    args=ap.parse_args()

    gold=_load_jsonl(args.golden)
    pred=_load_jsonl(args.pred)
    N=min(len(gold), len(pred))
    co = Counter()
    p_count = Counter()
    g_count = Counter()

    for i in range(N):
        G = set(d for d,_ in _extract_pairs(gold[i]))
        P = set(d for d,_ in _extract_pairs(pred[i]))
        for pd in P: p_count[pd]+=1
        for gd in G: g_count[gd]+=1
        for pd in P:
            for gd in G:
                co[(pd,gd)] += 1

    # 为每个 pred_doc 找到最可能的 gold_doc（>= min_votes）
    pred2gold = {}
    for (pd, gd), v in co.most_common():
        if v >= args.min_votes and pd not in pred2gold:
            pred2gold[pd] = gd

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out,"w",encoding="utf-8") as f:
        json.dump(pred2gold, f, ensure_ascii=False, indent=2)

    print(f"wrote {args.out} with {len(pred2gold)} pairs (min_votes={args.min_votes})")
    # 打印一些统计
    top_pred = ", ".join(f"{d}({n})" for d,n in p_count.most_common(8))
    top_gold = ", ".join(f"{d}({n})" for d,n in g_count.most_common(8))
    top_co   = ", ".join(f"{pd}->{gd}({co[(pd,gd)]})" for (pd,gd),_ in co.most_common(10))
    print(f"[Top pred docs] {top_pred}")
    print(f"[Top gold docs] {top_gold}")
    print(f"[Top co-occurs] {top_co}")

if __name__ == "__main__":
    main()
