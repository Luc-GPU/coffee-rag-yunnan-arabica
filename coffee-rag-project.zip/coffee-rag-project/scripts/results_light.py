# -*- coding: utf-8 -*-
# results_light.py (enhanced)
# Minimal eval focusing on latency breakdown + error taxonomy (no F1 tables).
# Changes:
#   - Force cross-encoder rerank in eval path (wrapper) so "rerank" latency is non-zero.
#   - Print config banner & rerank probe.
#   - Per-query progress line with component times; final shares summary.

import os, sys, json, time, importlib, re, csv, random
from typing import List, Dict, Any

# ----------------- utils -----------------
def guess_project_root(start: str) -> str:
    p = os.path.abspath(start)
    for _ in range(6):
        if os.path.isdir(os.path.join(p, "src")):
            return p
        p = os.path.dirname(p)
    return os.path.abspath(start)

def add_project_to_path(project_root: str):
    project_root = os.path.abspath(project_root)
    if project_root not in sys.path:
        sys.path.insert(0, project_root)
    return project_root

def read_jsonl(path: str) -> List[Dict[str,Any]]:
    out=[]
    with open(path,"r",encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if line:
                out.append(json.loads(line))
    return out

def write_jsonl(path: str, rows: List[Dict[str,Any]]):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path,"w",encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False)+"\n")

def quantiles(xs: List[float]) -> Dict[str,float]:
    if not xs: return {"p50":0,"p90":0,"p95":0}
    xs_sorted = sorted(xs)
    def pct(p):
        k = int(max(0, min(len(xs_sorted)-1, round(p*(len(xs_sorted)-1)))))
        return xs_sorted[k]
    return {"p50":pct(0.5),"p90":pct(0.9),"p95":pct(0.95)}

def parse_pairs(s: str) -> set:
    m = re.findall(r"\[\s*([A-Za-z0-9_-]{2,})\s*#\s*(\d+)\s*\]", s or "")
    return set((d.lower(), int(c)) for d,c in m)

def share(p, total):
    try:
        return 100.0 * float(p) / max(1e-12, float(total))
    except Exception:
        return 0.0

# ----------------- timers -----------------
class MonkeyTimers:
    def __init__(self, hybrid_mod, reranker_mod, gen_mod, enable_llm=True):
        self.hybrid_mod = hybrid_mod
        self.reranker_mod = reranker_mod
        self.gen_mod = gen_mod
        self.enable_llm = enable_llm
        self.t = {"bm25":0.0,"dense":0.0,"rrf":0.0,"rerank":0.0,"llm":0.0,"total":0.0}
    def __enter__(self):
        self._orig_bm25 = getattr(self.hybrid_mod, "_bm25_search", None)
        self._orig_dense= getattr(self.hybrid_mod, "_dense_search", None)
        self._orig_rrf  = getattr(self.hybrid_mod, "_rrf_merge", None)
        self._orig_rer  = getattr(self.reranker_mod, "rerank", None)
        self._orig_llm  = getattr(self.gen_mod, "_call_deepseek", None)

        def wrap(tkey, fn):
            def inner(*args, **kwargs):
                t0=time.perf_counter()
                out=fn(*args, **kwargs)
                self.t[tkey]+= (time.perf_counter()-t0)
                return out
            return inner

        if self._orig_bm25: setattr(self.hybrid_mod, "_bm25_search", wrap("bm25", self._orig_bm25))
        if self._orig_dense: setattr(self.hybrid_mod, "_dense_search", wrap("dense", self._orig_dense))
        if self._orig_rrf  : setattr(self.hybrid_mod, "_rrf_merge",  wrap("rrf",  self._orig_rrf))
        if self._orig_rer  : setattr(self.reranker_mod, "rerank",    wrap("rerank", self._orig_rer))
        if self._orig_llm  :
            if self.enable_llm:
                setattr(self.gen_mod, "_call_deepseek", wrap("llm", self._orig_llm))
            else:
                setattr(self.gen_mod, "_call_deepseek", lambda *a, **k: "")
        return self
    def __exit__(self, exc_t, exc, tb):
        if self._orig_bm25: setattr(self.hybrid_mod, "_bm25_search", self._orig_bm25)
        if self._orig_dense: setattr(self.hybrid_mod, "_dense_search", self._orig_dense)
        if self._orig_rrf  : setattr(self.hybrid_mod, "_rrf_merge", self._orig_rrf)
        if self._orig_rer  : setattr(self.reranker_mod, "rerank", self._orig_rer)
        if self._orig_llm  : setattr(self.gen_mod, "_call_deepseek", self._orig_llm)

# ----------------- main -----------------
def main():
    import argparse
    ap = argparse.ArgumentParser(description="Light Results (latency + error taxonomy)")
    ap.add_argument("--project", default="", help="project root; if omitted, auto-detect from CWD")
    ap.add_argument("--golden", default="eval/golden.jsonl", help="golden jsonl (optional; if missing, only NoCitation stats)")
    ap.add_argument("--results", default="results", help="results dir under project")
    ap.add_argument("--sample", type=int, default=0, help="subset N questions")
    ap.add_argument("--no-llm", dest="no_llm", action="store_true", help="skip LLM call (only retrieval+rerank timing)")
    ap.add_argument("--log-every", type=int, default=1, help="print progress every k queries")
    args = ap.parse_args()

    proj = args.project or guess_project_root(os.getcwd())
    proj = add_project_to_path(proj)
    results_dir = os.path.join(proj, args.results)
    os.makedirs(results_dir, exist_ok=True)

    # modules
    hybrid   = importlib.import_module("src.retrieval.hybrid_retriever")
    reranker = importlib.import_module("src.retrieval.reranker")
    gen      = importlib.import_module("src.generation.deepseek_generator")
    cfg      = importlib.import_module("src.config")

    # config snapshot
    FINAL_TOPK        = getattr(cfg, "FINAL_TOPK", 5)
    RERANK_CANDIDATES = getattr(cfg, "RERANK_CANDIDATES", 20)
    RERANKER_MODEL    = getattr(cfg, "RERANKER_MODEL", "BAAI/bge-reranker-base")
    ENABLE_RERANKER   = getattr(cfg, "ENABLE_RERANKER", True)
    BM25_TOKENIZER    = getattr(cfg, "BM25_TOKENIZER", "jieba")
    RETRIEVAL_MODE    = getattr(cfg, "RETRIEVAL_MODE", "hybrid")
    EMBED_MODEL_RETR  = getattr(cfg, "EMBED_MODEL_RETRIEVAL", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")

    print("="*72)
    print("[Config] RETRIEVAL_MODE =", RETRIEVAL_MODE,
          "| BM25_TOKENIZER =", BM25_TOKENIZER,
          "| EMBED_MODEL =", EMBED_MODEL_RETR)
    print("[Config] ENABLE_RERANKER =", ENABLE_RERANKER,
          "| RERANKER_MODEL =", RERANKER_MODEL)
    print("[Config] RERANK_CANDIDATES =", RERANK_CANDIDATES,
          "| FINAL_TOPK =", FINAL_TOPK)
    print("[Run]    LLM =", ("ON" if not args.no_llm else "OFF"),
          "| sample =", args.sample if args.sample>0 else "ALL")
    print("="*72)

    # base retriever (project-defined or fallback)
    try:
        retr = importlib.import_module("src.retrieval.retriever")
        my_ret = getattr(retr, "my_retriever")
    except Exception:
        class _Fallback:
            def __init__(self, final_topk:int=FINAL_TOPK):
                self.final_topk = final_topk
            def get_relevant_documents(self, q:str):
                return hybrid.hybrid(q, top_k=max(20, self.final_topk), dense_k=60, bm25_k=200)
        my_ret = _Fallback(FINAL_TOPK)

    # eval-only wrapper to enforce rerank
    class RerankWrapper:
        def __init__(self, base):
            self.base = base
        def get_relevant_documents(self, q: str):
            cands = self.base.get_relevant_documents(q)
            if not ENABLE_RERANKER:
                return cands[:FINAL_TOPK]
            pool = cands[:max(FINAL_TOPK, RERANK_CANDIDATES)]
            try:
                ranked = reranker.rerank(q, pool, top_k=FINAL_TOPK)
                return ranked
            except Exception as e:
                # graceful fallback but warn once
                if os.getenv("RERANK_WARNED","0")!="1":
                    print("[warn] rerank failed in wrapper:", e)
                    os.environ["RERANK_WARNED"]="1"
                return cands[:FINAL_TOPK]

    my_ret = RerankWrapper(my_ret)

    # quick probe: ensure rerank is callable (outside timers, just for visibility)
    try:
        probe_q = "云南小粒咖啡遮阴比例与海拔关系？"
        probe_cands = hybrid.hybrid(probe_q, top_k=10, dense_k=20, bm25_k=100)
        t0 = time.perf_counter()
        _ = reranker.rerank(probe_q, probe_cands[:max(5, min(20, len(probe_cands)))], top_k=3)
        t1 = time.perf_counter()
        print(f"[Probe] Cross-Encoder rerank OK, took {1000*(t1-t0):.1f} ms on a small pool.")
    except Exception as e:
        print(f"[Probe] Rerank probe FAILED: {e} (rerank latency may remain 0 if not called)")

    # golden
    golden_path = os.path.join(proj, args.golden) if not os.path.isabs(args.golden) else args.golden
    golden = []
    if os.path.exists(golden_path):
        try:
            golden = read_jsonl(golden_path)
        except Exception:
            golden = []
    if not golden:
        print("[warn] golden not found or empty; error taxonomy will be limited.")

    # optional id_map
    id_map={}
    id_map_path = os.path.join(proj, "eval/id_map.json")
    if os.path.exists(id_map_path):
        try:
            id_map = json.load(open(id_map_path,"r",encoding="utf-8"))
        except Exception:
            id_map={}
    def apply_id_map(pairs:set)->set:
        if not id_map: return pairs
        return set((id_map.get(d, d).lower(), c) for d,c in pairs)

    # queries
    rows=[]
    qrows = golden if golden else [{"query": "云南小粒咖啡适生温度和降水范围？"}]
    if args.sample>0 and golden:
        random.Random(42).shuffle(qrows)
        qrows=qrows[:args.sample]

    # run
    with MonkeyTimers(hybrid, reranker, gen, enable_llm=(not args.no_llm)) as MT:
        for i,row in enumerate(qrows,1):
            q=row.get("query","")
            gold_pairs=set()
            for tag in row.get("gold_citations",[]):
                m = re.findall(r"\[\s*([A-Za-z0-9_-]{2,})\s*#\s*(\d+)\s*\]", tag or "")
                for d,c in m: gold_pairs.add((d.lower(), int(c)))
            gold_pairs = apply_id_map(gold_pairs)
            sid=f"light-{i}"

            t_before = MT.t.copy()
            t0 = time.perf_counter()
            try:
                res = gen.generate_answer_with_retriever(session_id=sid, query=q, retriever=my_ret)
                ans = res.get("answer","")
            except Exception as e:
                ans = f"(error) {e}"
            elapsed_total = time.perf_counter() - t0
            MT.t["total"] += elapsed_total

            pred_pairs = apply_id_map(parse_pairs(ans))
            t_after = MT.t.copy()
            per_query = {k: t_after[k] - t_before[k] for k in t_after}
            per_query["total"] = elapsed_total

            rows.append({
                "idx": i,
                "query": q,
                "pred_pairs": sorted(list(pred_pairs)),
                "gold_pairs": sorted(list(gold_pairs)),
                "answer": ans[:3000],
                "times": per_query
            })

            # progress line
            if (i % max(1, args.log_every)) == 0:
                bm25 = per_query.get("bm25",0.0)
                dense= per_query.get("dense",0.0)
                rrf  = per_query.get("rrf",0.0)
                rrk  = per_query.get("rerank",0.0)
                llm  = per_query.get("llm",0.0)
                tot  = per_query.get("total",0.0)
                flag = []
                if rrk==0.0 and ENABLE_RERANKER: flag.append("RERANK=0?")
                if (not args.no_llm) and llm==0.0: flag.append("LLM=0?")
                msg = (f"[{i}/{len(qrows)}] "
                       f"bm25={bm25:.3f}s dense={dense:.3f}s rrf={rrf:.4f}s "
                       f"rerank={rrk:.3f}s llm={llm:.3f}s total={tot:.3f}s "
                       f"cites={len(pred_pairs)} {'| ' + ','.join(flag) if flag else ''}")
                print(msg)

    # write per-query latency
    write_jsonl(os.path.join(results_dir, "latency_light.jsonl"), rows)

    # latency summary
    comp = {k:[r["times"].get(k,0.0) for r in rows] for k in ("bm25","dense","rrf","rerank","llm","total")}
    lat_summary = {k: {"mean": (sum(v)/max(1,len(v))), **quantiles(v)} for k,v in comp.items()}
    json.dump(lat_summary, open(os.path.join(results_dir,"latency_summary.json"),"w",encoding="utf-8"),
              ensure_ascii=False, indent=2)

    # pretty print shares
    m = lat_summary
    bm25 = m["bm25"]["mean"]; dense = m["dense"]["mean"]; rrf = m["rrf"]["mean"]
    rrk  = m["rerank"]["mean"]; llm  = m["llm"]["mean"];   total= m["total"]["mean"]
    shares = {
        "BM25%": round(share(bm25,total),2),
        "Dense%": round(share(dense,total),2),
        "RRF%": round(share(rrf,total),2),
        "Rerank%": round(share(rrk,total),2),
        "LLM%": round(share(llm,total),2),
    }
    shares["Unattributed%"] = round(100 - sum(shares.values()), 2)

    print("-"*72)
    print("[Latency mean (s)]",
          f"bm25={bm25:.3f}, dense={dense:.3f}, rrf={rrf:.4f}, rerank={rrk:.3f}, llm={llm:.3f}, total={total:.3f}")
    print("[Latency shares ]", ", ".join([f"{k}={v}%" for k,v in shares.items()]))
    print("-"*72)

    # error taxonomy (light)
    err_rows=[]
    counts={"NoCitation":0,"WrongDoc":0,"WrongChunk":0,"MissingEvidence":0}
    golden_used = bool(golden)
    if golden_used:
        for r in rows:
            G=set(map(tuple, r["gold_pairs"]))
            P=set(map(tuple, r["pred_pairs"]))
            if not G: continue
            if not P:
                counts["NoCitation"]+=1
                err_rows.append([r["idx"], "NoCitation", r["pred_pairs"], r["gold_pairs"]])
                continue
            gold_docs=set(d for d,_ in G)
            for pd,pc in P-G:
                if pd not in gold_docs:
                    counts["WrongDoc"]+=1; et="WrongDoc"
                else:
                    counts["WrongChunk"]+=1; et="WrongChunk"
                err_rows.append([r["idx"], et, r["pred_pairs"], r["gold_pairs"]])
            for gd,gc in G-P:
                counts["MissingEvidence"]+=1
                err_rows.append([r["idx"], "MissingEvidence", r["pred_pairs"], r["gold_pairs"]])
        with open(os.path.join(results_dir,"error_taxonomy_light.csv"),"w",encoding="utf-8",newline="") as f:
            w=csv.writer(f); w.writerow(["idx","type","pred_pairs","gold_pairs"]); w.writerows(err_rows)
        json.dump(counts, open(os.path.join(results_dir,"error_summary.json"),"w",encoding="utf-8"),
                  ensure_ascii=False, indent=2)
    else:
        nocite = sum(1 for r in rows if not r["pred_pairs"])
        json.dump({"NoCitation": nocite, "total": len(rows)},
                  open(os.path.join(results_dir,"error_summary.json"),"w",encoding="utf-8"),
                  ensure_ascii=False, indent=2)
        with open(os.path.join(results_dir,"error_taxonomy_light.csv"),"w",encoding="utf-8",newline="") as f:
            w=csv.writer(f); w.writerow(["idx","has_citation","pred_pairs"])
            for r in rows:
                w.writerow([r["idx"], 1 if r["pred_pairs"] else 0, r["pred_pairs"]])

    print(json.dumps({"latency": lat_summary, "shares": shares,
                      "errors": counts if golden_used else {"NoCitation": nocite, "total": len(rows)}},
                     ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
