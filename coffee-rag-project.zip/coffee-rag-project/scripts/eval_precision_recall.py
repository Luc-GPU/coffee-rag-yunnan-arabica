# scripts/eval_precision_recall.py
# 批量评测 RAG：生成预测 → 解析引用 → 计算 Precision / Recall
import os
import json
import re
import time
import argparse
from typing import List, Dict, Any

# 你的项目内函数
from src.retrieval.retriever import my_retriever
from src.generation.deepseek_generator import generate_answer_with_retriever
from src.config import ENABLE_QUERY_REWRITE, ENABLE_RERANKER, ENABLE_HYBRID_RETRIEVAL

CITATION_RE = re.compile(r"\[\s*([^\[\]#]+)\s*#\s*([^\[\]]+)\s*\]")  # 兼容空格

def parse_citations(answer: str) -> List[str]:
    """从答案中解析 [source#chunk_id]，返回形如 'source#chunk_id' 的列表（去重保序）"""
    seen = set()
    ordered = []
    for m in CITATION_RE.finditer(answer or ""):
        src = m.group(1).strip()
        src = src.split()[0] if src else src
        cid = m.group(2).strip()
        key = f"{src}#{cid}"
        if key not in seen:
            seen.add(key)
            ordered.append(key)
    return ordered

def load_jsonl(path: str) -> List[Dict[str, Any]]:
    out = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out

def save_jsonl(path: str, rows: List[Dict[str, Any]]):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def evaluate(golden_rows: List[Dict[str, Any]], pred_rows: List[Dict[str, Any]]) -> Dict[str, float]:
    """基于引用的精确率/召回率（宏平均）"""
    assert len(golden_rows) == len(pred_rows), "golden 与 pred 条数必须一致"
    total_prec, total_rec, count = 0.0, 0.0, 0
    for g, p in zip(golden_rows, pred_rows):
        gold = set(g.get("gold_citations", []) or [])
        pred = set(p.get("pred_citations", []) or [])
        if not gold:
            # 没有金标引用就跳过，不计入平均
            continue
        tp = len(gold & pred)
        prec = tp / len(pred) if pred else 0.0
        rec = tp / len(gold) if gold else 0.0
        total_prec += prec
        total_rec += rec
        count += 1
    return {
        "Precision": (total_prec / count) if count else 0.0,
        "Recall": (total_rec / count) if count else 0.0,
        "Count": count
    }

def run_eval(
    golden_path: str,
    pred_path: str,
    session_prefix: str = "eval",
    sleep_s: float = 0.0,
    use_rewrite: bool = True
):
    golden = load_jsonl(golden_path)
    preds = []

    print("=== 评测配置 ===")
    print(f"ENABLE_QUERY_REWRITE: {ENABLE_QUERY_REWRITE} (本次强制 use_rewrite={use_rewrite})")
    print(f"ENABLE_RERANKER: {ENABLE_RERANKER}")
    print(f"ENABLE_HYBRID_RETRIEVAL: {ENABLE_HYBRID_RETRIEVAL}")
    print(f"golden size: {len(golden)}")

    for i, row in enumerate(golden, 1):
        q = row["query"]
        sid = f"{session_prefix}-{i}"
        print(f"\n[{i}/{len(golden)}] Q: {q}")

        res = generate_answer_with_retriever(
            session_id=sid,
            query=q,
            retriever=my_retriever,
            use_rewrite=use_rewrite
        )
        ans = res["answer"]
        cites = parse_citations(ans)

        pred_row = {
            "query": q,
            "answer": ans,
            "pred_citations": cites,
            "rewritten_query": res.get("rewritten_query"),
            "num_context_docs": res.get("num_context_docs"),
            "debug": res.get("debug", {})
        }
        preds.append(pred_row)
        print(f"→ 引用: {cites}")
        if sleep_s > 0:
            time.sleep(sleep_s)

    save_jsonl(pred_path, preds)

    # 若 golden 有 gold_citations，则做指标
    has_gold = any((r.get("gold_citations") for r in golden))
    if has_gold:
        metrics = evaluate(golden, preds)
        print("\n=== 指标（宏平均）===")
        print(f"Precision: {metrics['Precision']:.3f}")
        print(f"Recall   : {metrics['Recall']:.3f}")
        print(f"Count    : {metrics['Count']}")
    else:
        print("\n提示：golden.jsonl 没有 gold_citations，跳过指标计算。")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="RAG 引用级 Precision/Recall 评测")
    parser.add_argument("--golden", default="eval/golden.jsonl", help="金标路径")
    parser.add_argument("--pred",   default="eval/pred.jsonl", help="预测输出路径")
    parser.add_argument("--sid",    default="eval", help="session_id 前缀")
    parser.add_argument("--sleep",  type=float, default=0.0, help="每题之间 sleep 秒数（限流用）")
    parser.add_argument("--no-rewrite", action="store_true", help="关闭本次评测的 Query Rewrite")
    args = parser.parse_args()

    run_eval(
        golden_path=args.golden,
        pred_path=args.pred,
        session_prefix=args.sid,
        sleep_s=args.sleep,
        use_rewrite=(not args.no_rewrite),
    )